﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsRobot
{
    //Interface to get the final position of Robot
    interface IRobotPosition
    {
        string getFinalPosition(String command, int x, int y);
    }

}
