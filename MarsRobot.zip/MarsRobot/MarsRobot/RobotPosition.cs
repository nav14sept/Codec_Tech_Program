﻿
using System;

namespace MarsRobot
{
    //Robot class implementing IRobotPosition interface
    //to calculate Robot Position
    public class RobotPosition : IRobotPosition
    {
        // to find final position of
        // the robot after moving as per the command
        public string getFinalPosition(String command, int x, int y)
        {
            int l = command.Length;
            // robot will always start at X: 1, Y: 1 facing NORTH
            int moveForward = 1, move = 1;
            string direction = "North";

            // traverse through the command string 
            // FFRFLFLF
            try
            {
                for (int i = 0; i < l; i++)
                {
                    //move steps forward(++) and backward(--)
                    //as per the directions set through command
                    if (command[i] == 'F')
                    {
                        //If the robot reaches the limits of the plateau
                        //the command must be ignored, should not exceed the given limits x and y
                        //There is no 0,0 position,
                        //therefore position should never comes lesser then 1,1 
                        if (direction == "North" && moveForward < y)
                            moveForward++;
                        else if (direction == "South" && moveForward > 1)
                            moveForward--;
                        else if (direction == "East" && move > 1)
                            move--;
                        else if (direction == "West" && move < x)
                            move++;

                        //once the Robot moves forward, fetch the next command character
                        //no need to traverse further
                        continue;
                    }

                    //set the direction based on current direction and the command character
                    //by default the first direction is North
                    if (command[i] == 'L')
                    {
                        if (direction == "North")
                            direction = "East";
                        else if (direction == "South")
                            direction = "West";
                        else if (direction == "East")
                            direction = "South";
                        else if (direction == "West")
                            direction = "North";
                    }
                    else if (command[i] == 'R')
                    {
                        if (direction == "North")
                            direction = "West";
                        else if (direction == "South")
                            direction = "East";
                        else if (direction == "East")
                            direction = "North";
                        else if (direction == "West")
                            direction = "South";
                    }
                }

                // required final position of robot
                Console.WriteLine("Final Position of Robot: "
                                + (move) + ", "             //x-coordinate
                                + (moveForward) + ", "      //y-coordinate
                                + (direction));             //Robot facing position

                return "Success";
            }
            catch
            {
                Console.Write("Error Occured, Please contact the developer of this program.");
                return "Failed";
            }
        }
    }
}
