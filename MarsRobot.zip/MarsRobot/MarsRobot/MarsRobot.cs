﻿

using System;

namespace MarsRobot
{
    // C# program implementation to determine the final position
    // of robot after completing movement as per the command given
    public class MarsRobot
    {
        public static void Main()
        {
            try
            {
                Console.WriteLine("****Mars Robot Program****");
                Console.WriteLine("Limits must be Numerical and command should be consist of following characters - F, R, L.");
                Console.WriteLine("Please enter the maximum limits for Mars plateau grid: ");
                
                //get the Maximum limits as input
                int x = Convert.ToInt32(Console.ReadLine());
                int y = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Please enter the command using characters F, R, L: ");
                //get the command as second input
                String? command = Console.ReadLine();

                RobotPosition position = new RobotPosition();

                if (command != null)
                    position.getFinalPosition(command, x, y);
                else
                    Console.WriteLine("Command is missing");
            }
            catch
            {
                Console.Write("Error occurred, Please check the input parameters.");
            }
        }
    }
}
