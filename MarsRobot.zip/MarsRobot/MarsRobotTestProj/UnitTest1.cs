using MarsRobot; 

namespace MarsRobotTestProj
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void TestMethod()
        {
            RobotPosition position = new RobotPosition();
            string result = position.getFinalPosition("", 5, 4);
            Assert.AreEqual("Success", result);
        }


        [TestMethod]
        public void TestMethod1()
        {
            RobotPosition position = new RobotPosition();
            string result = position.getFinalPosition("ABC", 0, 0);
            Assert.AreEqual("Success", result);
        }

        [TestMethod]
        public void TestMethod2()
        {
            RobotPosition position = new RobotPosition();
            string result = position.getFinalPosition("FRLABLR", 2, 8);
            Assert.AreEqual("Success", result);
        }

        [TestMethod]
        public void TestMethod3()
        {
            RobotPosition position = new RobotPosition();
            string result = position.getFinalPosition("FRLLR", 199, 999);
            Assert.AreEqual("Success", result);
        }

        [TestMethod]
        public void TestMethod4()
        {
            RobotPosition position = new RobotPosition();
            string result = position.getFinalPosition("FRLLR", -2, -5);
            Assert.AreEqual("Success", result);
        }

        [TestMethod]
        public void TestMethod5()
        {
            RobotPosition position = new RobotPosition();
            string result = position.getFinalPosition("FRLFLRFRFFFFRLLFRFRFRRRRFRLLFFFRFFFLLR", 50,50 );
            Assert.AreEqual("Success", result);
        }


        [TestMethod]
        public void TestMethod6()
        {
            RobotPosition position = new RobotPosition();
            string result = position.getFinalPosition("FRLFL FFLLR", 10, 10);
            Assert.AreEqual("Success", result);
        }

    }
}