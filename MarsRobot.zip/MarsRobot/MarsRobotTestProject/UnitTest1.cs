﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;


namespace MarsRobotTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestRobotPosition()
        {
            //RobotPosition position = new RobotPosition();
        }
    }
}
